#!/bin/bash

timeout --foreground 3600 qemu-system-aarch64 \
    -machine virt \
    -m 128M \
    -cpu max \
    -smp cores=1,threads=1 \
    -kernel ./Image \
    -initrd ./initramfs.cpio.gz \
    -no-reboot \
    -append "console=ttyAMA0 nokaslr smap smep kpti quiet log_level=0 panic=1" \
    -nographic