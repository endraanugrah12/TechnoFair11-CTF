#!/bin/sh
qemu-system-x86_64 \
    -m 128M \
    -nographic \
    -kernel ./bzImage \
    -initrd ./initramfs.cpio.gz \
    -append "console=ttyS0 quiet oops=panic panic=1 kaslr kpti" \
    -no-reboot \
    -cpu kvm64,+smap,+smep \
    -monitor /dev/null \
